# Contas Bot

Bot inicial de loja para Discord usando Discord.js.

## Comandos

- `/loja` — mostra o estoque.
- `/produto id:` — mostra um produto.
- `/adicionar nome: preco:` — adiciona produto (administradores).
- `/remover id:` — remove produto (administradores).
- `/vendas` — mostra o fluxo de venda.

## Importante

O estoque deste primeiro modelo fica apenas na memória do processo. Ao reiniciar o bot, os produtos são perdidos.

Na próxima etapa podemos adicionar:
- banco de dados;
- sistema de tickets;
- botões de compra;
- painel de administrador;
- integração de pagamento;
- logs;
- persistência do estoque.

Não coloque token do Discord, senha de conta de jogo ou outras credenciais em arquivos públicos/GitHub.

## Rodar localmente

1. Instale Node.js 20+.
2. Copie `.env.example` para `.env`.
3. Preencha as variáveis.
4. Rode `npm install`.
5. Rode `npm start`.
